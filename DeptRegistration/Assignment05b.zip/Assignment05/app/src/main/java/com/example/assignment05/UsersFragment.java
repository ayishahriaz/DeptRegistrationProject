package com.example.assignment05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.example.assignment05.databinding.FragmentUsersBinding;
import com.example.assignment05.databinding.ListItemMoodBinding;
import com.example.assignment05.databinding.ListItemUserBinding;

public class UsersFragment extends Fragment {
    public UsersFragment() {
        // Required empty public constructor
    }

    FragmentUsersBinding binding;
    ArrayList<User> mUsers = new ArrayList<>();
    UserAdapter adapter;
    ArrayList<Mood> moodList = new ArrayList<>();

    ListView moodListView;


    public static final int SORT_BY_NAME_ASC= 1;
    public static final int SORT_BY_NAME_DES = 2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentUsersBinding.inflate(inflater, container, false);

        return binding.getRoot();


    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Users");
        mUsers = mListener.getUserList();

        adapter = new UserAdapter();
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.recyclerView.setAdapter(adapter);

        //clear all users and notify adapter
        binding.buttonClearAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.clearUserList();
                adapter.notifyDataSetChanged();
            }
        });
        binding.buttonAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.openAddUserFragment();
            }
        });

        binding.imageViewSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.openSortFragment();
            }
        });

        binding.imageViewFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.openFilterFragment();
            }
        });

    }

    UserAdapter userAdapter;
    public UserAdapter getUserAdapter() {
        return userAdapter;
    }


    UsersFragmentListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (UsersFragmentListener) context;
    }

    interface UsersFragmentListener {
         ArrayList<User> getUserList();
         void showProfile(User user);
         void clearUserList();
         void openAddUserFragment();
         void openSortFragment();
         void openFilterFragment();
    }


    class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
        @NonNull
        @Override
        //inflate the row you want to display (users)
        public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ListItemUserBinding binding = ListItemUserBinding.inflate(getLayoutInflater(), parent, false);
      return new UserViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
            User user = mUsers.get(position);
            holder.setupUI(user);
        }

        @Override
        public int getItemCount() {
            return mUsers.size();
        }


        class UserViewHolder extends RecyclerView.ViewHolder {
          ListItemUserBinding mBinding;
          User uUser;
            public UserViewHolder (@NonNull ListItemUserBinding binding) {
                super(binding.getRoot());
                mBinding = binding;

                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                       mListener.showProfile(uUser);
                    }
                });

            }
            public void setupUI (User user) {
                mBinding.textViewUserName.setText(user.getName());
                mBinding.textViewUserAgeGroup.setText(user.getAgeGroup());
                mBinding.imageViewUserMood.setImageResource(user.getMood().imageResourceId);

                uUser = user;



                mBinding.imageViewDelete.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        mUsers.remove(uUser);
                        if(mUsers.size() == 0) {
                            //doesn't clear the last item
                            mListener.clearUserList();
                        } else {
                            notifyDataSetChanged();
                        }

                    }
                });
            }
        }
    }









}
