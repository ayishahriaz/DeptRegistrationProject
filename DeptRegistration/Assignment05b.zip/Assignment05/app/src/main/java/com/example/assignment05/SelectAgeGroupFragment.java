package com.example.assignment05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.assignment05.databinding.FragmentSelectAgeGroupBinding;
import com.example.assignment05.databinding.FragmentSelectMoodBinding;

public class SelectAgeGroupFragment extends Fragment {
    String[] ageGroups = {"Under 12 years old", "12-17 years old", "18-24 years old", "25-34 years old", "35-44 years old", "45-54 years old", "55-64 years old", "65-74 years old", "75 years or older"};
    ListView listView;
    ArrayAdapter<String> adapter;


    public SelectAgeGroupFragment() {
        // Required empty public constructor
    }

    FragmentSelectAgeGroupBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSelectAgeGroupBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Select Age Group");

        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, ageGroups);
        binding.listView.setAdapter(adapter);


        binding.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                String selectedAgeGroup = ageGroups[position];
                mListener.sendSelectedAgeGroup(selectedAgeGroup);
            }
        });


        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               mListener.closeSelectAgeGroupFragment();
            }
        });
    }


    SelectAgeGroupFragmentListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (SelectAgeGroupFragmentListener) context;
    }

    interface SelectAgeGroupFragmentListener {
        void sendSelectedAgeGroup(String selectedAgeGroup);
        void closeSelectAgeGroupFragment();
    }
}