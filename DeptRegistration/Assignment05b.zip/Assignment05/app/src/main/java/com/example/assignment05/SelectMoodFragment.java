package com.example.assignment05;

import android.content.Context;
import android.media.Image;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.assignment05.databinding.FragmentAddUserBinding;
import com.example.assignment05.databinding.FragmentSelectMoodBinding;

import java.util.ArrayList;
import java.util.List;


public class SelectMoodFragment extends Fragment {


    public SelectMoodFragment() {
        // Required empty public constructor
    }


    FragmentSelectMoodBinding binding;
   // ListView moodListView;
   // ArrayList<Mood> moodList = new ArrayList<>();


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentSelectMoodBinding.inflate(inflater, container, false);



        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Select Mood");

        ListView listView = binding.getRoot().findViewById(R.id.listView);
        ArrayList<Mood> moodList = new ArrayList<>();
        moodList.add(new Mood("Good", R.drawable.good));
        moodList.add(new Mood("Not Well", R.drawable.not_well));
        moodList.add(new Mood("Ok", R.drawable.ok));
        moodList.add(new Mood("Sad", R.drawable.sad));
        moodList.add(new Mood("Very Good", R.drawable.very_good));

        MoodAdapter moodAdapter = new MoodAdapter(requireContext(), R.id.listView, moodList);
        listView.setAdapter(moodAdapter);


        binding.listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Mood selectedMood = moodAdapter.getItem(position);
                mListener.sendSelectedMood(selectedMood);

            }

        });


        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.closeMoodFragment();

            }
        });
    }

    SelectMoodFragmentListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (SelectMoodFragmentListener) context;
    }

    interface SelectMoodFragmentListener {
        void sendSelectedMood (Mood selectedMood);
        void closeMoodFragment();
    }

    static class MoodAdapter extends ArrayAdapter<Mood> {
        public MoodAdapter(@NonNull Context context, int resource, @NonNull List<Mood> objects) {
            super(context, resource, objects);
        }


        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            if(convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_mood, parent, false);
            }
            Mood mood = getItem(position);

            TextView textViewMood = convertView.findViewById(R.id.textViewMood);
            ImageView imageViewMood = convertView.findViewById(R.id.imageViewMood);

            textViewMood.setText(mood.getName());
            imageViewMood.setImageResource(mood.getImageResourceId());

            if (mood != null) {
                textViewMood.setText(mood.getName());
                imageViewMood.setImageResource(mood.getImageResourceId());
            }
            return convertView;
        }
    }


}
