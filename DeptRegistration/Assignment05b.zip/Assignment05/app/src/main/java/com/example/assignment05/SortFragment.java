package com.example.assignment05;

import static com.example.assignment05.UsersFragment.SORT_BY_NAME_ASC;
import static com.example.assignment05.UsersFragment.SORT_BY_NAME_DES;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.assignment05.databinding.FragmentSortBinding;

import java.util.Collections;
import java.util.Comparator;

public class SortFragment extends Fragment {

private int selectedSortOption = -1;
    FragmentSortBinding binding;


    public SortFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentSortBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Sort");

        binding.imageViewNameAsc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    mListener.sortSelection(SORT_BY_NAME_ASC);
            }
        });

        binding.imageViewNameDesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    mListener.sortSelection(SORT_BY_NAME_DES);

            }
        });




        binding.buttonCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getParentFragmentManager().popBackStack();
            }
        });

    }
SortFragmentListener mListener;
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener = (SortFragmentListener) context;
    }

    interface SortFragmentListener{
        void sortSelection(int sortOption);
    }
}