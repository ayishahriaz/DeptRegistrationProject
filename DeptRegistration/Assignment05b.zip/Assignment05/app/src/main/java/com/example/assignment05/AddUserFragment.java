package com.example.assignment05;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.assignment05.databinding.FragmentAddUserBinding;

public class AddUserFragment extends Fragment {
    EditText nameEt;
    TextView selectAgeTxt;
    TextView moodName;
    ImageView moodImage;
    static String age;
    static String moodSelect;

    public AddUserFragment() {
        // Required empty public constructor
    }

FragmentAddUserBinding binding;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentAddUserBinding.inflate(inflater, container, false);

        nameEt = binding.editTextText;
        selectAgeTxt = binding.textViewAgeGroup;
        moodImage = binding.imageViewMood;
        moodName = binding.textViewMood;
        selectAgeTxt.setText(age);
        moodName.setText(moodSelect);

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        getActivity().setTitle("Add New User");


        binding.buttonSelectAge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.openSelectAgeGroupFragment();
            }
        });

        if(selectedAgeGroup == null) {
            selectAgeTxt.setText("");
        } else {
            selectAgeTxt.setText(selectedAgeGroup.toString());
        }


        binding.buttonSelectMood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mListener.openSelectMoodFragment();
            }
        });
        if(selectedMood != null ) {
            binding.imageViewMood.setVisibility(View.VISIBLE);
            binding.imageViewMood.setImageResource(selectedMood.getImageResourceId());
            binding.textViewMood.setText(selectedMood.getName());
        }

        binding.buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEt.getText().toString();
                String age = selectAgeTxt.getText().toString();
                Mood mood = selectedMood;

                if (!name.isEmpty() && !age.equals("") && !mood.equals("")) {
                    User newUser = new User(name, age, mood);
                    mListener.addUser(newUser);
                        mListener.goToUserFragment();
                }else {
                    Toast.makeText(requireContext(), "Missing User Information!!!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    AddUserFragmentListener mListener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mListener= (AddUserFragmentListener) context;
    }

    private String selectedAgeGroup = "";
    public void setSelectedAgeGroup(String selectedAgeGroup) {
        Log.d("AddUserFragment", "Setting selectedAgeGroup: " + selectedAgeGroup);
        this.selectedAgeGroup = selectedAgeGroup;
    }

    private Mood selectedMood;
    public void setSelectedMood(Mood selectedMood) {
        this.selectedMood = selectedMood;
    }

    interface AddUserFragmentListener {
        void addUser(User user);
        void openSelectAgeGroupFragment();
        void openSelectMoodFragment();
        void goToUserFragment();
    }
}