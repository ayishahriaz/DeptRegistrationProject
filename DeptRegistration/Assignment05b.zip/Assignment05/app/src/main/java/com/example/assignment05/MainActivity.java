package com.example.assignment05;

import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;


import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity implements UsersFragment.UsersFragmentListener, SortFragment.SortFragmentListener, SelectMoodFragment.SelectMoodFragmentListener, AddUserFragment.AddUserFragmentListener, SelectAgeGroupFragment.SelectAgeGroupFragmentListener {

    ArrayList<User> mUsers = new ArrayList<>();
    private UsersFragment usersFragment;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUsers.add(new User("Bob Smith", "18-24 years old", new Mood("Good", R.drawable.good)));
        mUsers.add(new User("Tom Green", "25-34 years old", new Mood("Very Good", R.drawable.very_good)));
        mUsers.add(new User("Bob Smith", "35-44 years old", new Mood("Ok", R.drawable.ok)));

      /*  moodList.add(new Mood("Good", R.drawable.good));
        moodList.add(new Mood("Not Well", R.drawable.not_well));
        moodList.add(new Mood("Ok", R.drawable.ok));
        moodList.add(new Mood("Sad", R.drawable.sad));
        moodList.add(new Mood("Very Good", R.drawable.very_good));
*/


        usersFragment = new UsersFragment();
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.rootView, new UsersFragment())
                .commit();

    }

    @Override
    public ArrayList<User> getUserList() {
        return mUsers;
    }

    @Override
    public void showProfile(User user) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, ProfileFragment.newInstance(user))
                .addToBackStack(null)
                .commit();
    }


    @Override
    public void clearUserList() {
            mUsers.clear();

    }

    @Override
    public void openAddUserFragment() {
        getSupportFragmentManager()
                .beginTransaction().addToBackStack(null)
                .replace(R.id.rootView, new AddUserFragment())
                .commit();
    }

    @Override
    public void openSortFragment() {
        getSupportFragmentManager()
                .beginTransaction().addToBackStack(null)
                .replace(R.id.rootView, new SortFragment())
                .commit();
    }

    @Override
    public void openFilterFragment() {
        getSupportFragmentManager()
                .beginTransaction().addToBackStack(null)
                .replace(R.id.rootView, new FilterFragment())
                .commit();
    }


    @Override
    public void sortSelection(int sortOption) {
            // Call the sortUsers method in the UsersFragment
           // usersFragment.sortUsers(sortOption);

    }



    @Override
    public void addUser(User user) {
        mUsers.add(user);
    }

    @Override
    public void openSelectAgeGroupFragment() {
                getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SelectAgeGroupFragment())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void openSelectMoodFragment() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, new SelectMoodFragment())
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void goToUserFragment() {
        UsersFragment fragment = (UsersFragment) getSupportFragmentManager().findFragmentByTag("user-fragment");
            fragment = new UsersFragment();

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, fragment, "add-user-fragment")
                .addToBackStack(null)
                .commit();

    }

    @Override
    public void sendSelectedAgeGroup(String selectedAgeGroup) {
        AddUserFragment fragment = new AddUserFragment();
        fragment.setSelectedAgeGroup(selectedAgeGroup);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.rootView, fragment, "add-user-fragment")
                .addToBackStack(null)
                .commit();
    }

    @Override
    public void sendSelectedMood(Mood mood) {
        AddUserFragment fragment = (AddUserFragment) getSupportFragmentManager().findFragmentByTag("add-user-fragment");
            fragment.setSelectedMood(mood);

            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.rootView, fragment, "add-user-fragment")
                    .addToBackStack(null)
                    .commit();
        }



    @Override
    public void closeSelectAgeGroupFragment() {
        getSupportFragmentManager().popBackStack(); //go back to previous fragment
    }

    @Override
    public void closeMoodFragment() {
        getSupportFragmentManager().popBackStack();
    }
}